from rest_framework import serializers
from django.contrib.auth.models import User


class CurrencySerializers(serializers.Serializer):
    amount = serializers.CharField()
    currency = serializers.CharField()
