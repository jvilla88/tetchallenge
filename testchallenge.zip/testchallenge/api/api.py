from rest_framework.response import Response
from .serializers import CurrencySerializers
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.permissions import IsAdminUser


fee_cost = .08
currency_money = "USD"
values = {"EUR": 1.18,
          "USD": 1,
          "JPY": .0090,
          "GBP": 1.38,
          "CHF": 1.08,
          "AUD": 0.75,
          "CAD": 0.80,
          "NZD": 0.70
          }


class UserAPI(APIView):

    ppermission_classes = [IsAdminUser]
    http_method_names = ['get', 'head', 'post']

    def get(self, request, format=None):
        #del request.session['balance']
        checkvalues = request.session['balance']
        if checkvalues == "":
            request.session["curr"] = {"EUR": 1000, "USD": 1000, "JPY": 8000, "GBP": 1000,
                                       "CHF": 1000, "AUD": 1000, "CAD": 1000, "NZD": 1000}

        return Response({'balance': request.session["curr"], "fee_cost": fee_cost,
                        "currency_money": currency_money, "money_value": values})

    def post(self, request, format=None):
        self.http_method_names.append("GET")
        serializer = CurrencySerializers(data=request.data)
        if serializer.is_valid():
            precalc = pre_calculate(
                request, serializer.data["currency"], serializer.data["amount"])
            request.session.modified = True
            request.session['balance'] = True
            return Response({"Message": precalc}, status=status.HTTP_201_CREATED)
        return Response({"Error": "Error"}, status=status.HTTP_400_BAD_REQUEST)


def pre_calculate(request, c_type, amount):
    curr_money = "{:.2f}".format(request.session['curr'][c_type])
    #total = float(curr_money)-float(amount)
    fecost_amount = float(fee_cost)*float(amount)
    currency_feecost = float(values[currency_money])-float(fee_cost)
    total_to_send = float(currency_feecost)*float(amount)
    feecost_total = float(total_to_send)
    convert_to_currency = float(total_to_send)/float(values[c_type])
    if(float(curr_money) >= float(convert_to_currency)):
        total = float(curr_money) - float(convert_to_currency)
        request.session['curr'][c_type] = total
        current_json = {"SUCCESS": "Change Accepted", "total_fee_cost": fecost_amount,
                        "amount": amount, "total_currency": "{:.2f}".format(convert_to_currency), "c_type": c_type}
    else:
        current_json = {"ERROR": "Not Enough Balance",
                        "Currency": c_type, "Current Amount": curr_money, "Minimun required Amount": convert_to_currency}
    return (current_json)
