# Profiles REST API

# 1.- Uncompress file .zip un any directory (Linux/MacOs enviroment)

# 2.- Access to folder testchallenge and type % docker-conmpose up

# 3.- To post and get data use Postman application (see video for reference) and type this url http://127.0.0.1:8000/api/1.0/currency/

# 4.- Use this dictionary to post data: {"amount": "10","currency": "EUR"} (you can update values for amount and currency as you wish)

# THANK YOU
